package org.example.crapsgame.view.alert;

public interface IAlertBox {
    void showMessage(String title, String header, String content);
}
